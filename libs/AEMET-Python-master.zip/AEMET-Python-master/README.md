AEMET-Python-API
================

API en python para consultar los datos de localidades de la Agencia Estatal de Meteorología (AEMET)
